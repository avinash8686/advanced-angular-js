

// in normal cases, controller is just a function
myApp.controller('mainController',function(){


});

// in case of service, 

myApp.controller('mainController',['$http','$location',function($http,$location){








}])